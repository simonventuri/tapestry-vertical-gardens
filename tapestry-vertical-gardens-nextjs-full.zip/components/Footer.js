
export default function Footer(){
  return <footer><p>&copy; {new Date().getFullYear()} Tapestry Vertical Gardens. All rights reserved.</p></footer>
}
